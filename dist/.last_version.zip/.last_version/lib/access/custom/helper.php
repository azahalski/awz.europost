<?php
namespace Awz\Europost\Access\Custom;

class Helper
{
    public const ADMIN_DECLINE = 1;
}