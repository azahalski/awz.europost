<?php
namespace Awz\Europost\Access\Custom;

use Awz\Europost\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}