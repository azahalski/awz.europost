<?php
return array(
    'controllers' => array(
        'value' => array(
            'namespaces' => array(
                '\\Awz\\Europost\\Api\\Controller' => 'api'
            )
        ),
        'readonly' => true
    )
);