<?
$arModuleVersion = array(
    "VERSION" => "1.1.4",
    "VERSION_DATE" => "2024-04-30 06:54:00"
);