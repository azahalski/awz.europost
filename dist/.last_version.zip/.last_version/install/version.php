<?
$arModuleVersion = array(
    "VERSION" => "1.0.6",
    "VERSION_DATE" => "2022-12-11 19:48:00"
);