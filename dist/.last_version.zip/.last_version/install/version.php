<?
$arModuleVersion = array(
    "VERSION" => "1.2.4",
    "VERSION_DATE" => "2025-06-21 12:29:00"
);