<?
$arModuleVersion = array(
    "VERSION" => "1.0.5",
    "VERSION_DATE" => "2022-07-14 10:44:00"
);