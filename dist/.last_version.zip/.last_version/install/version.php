<?
$arModuleVersion = array(
    "VERSION" => "1.2.3",
    "VERSION_DATE" => "2024-12-08 17:13:00"
);