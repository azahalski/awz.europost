<?
$arModuleVersion = array(
    "VERSION" => "1.2.1",
    "VERSION_DATE" => "2024-12-08 16:46:00"
);