<?
$arModuleVersion = array(
    "VERSION" => "1.1.0",
    "VERSION_DATE" => "2023-07-02 09:29:00"
);