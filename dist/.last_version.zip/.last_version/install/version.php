<?
$arModuleVersion = array(
    "VERSION" => "1.0.7",
    "VERSION_DATE" => "2023-03-28 12:54:00"
);