<?
$arModuleVersion = array(
    "VERSION" => "1.2.5",
    "VERSION_DATE" => "2025-06-26 12:29:00"
);