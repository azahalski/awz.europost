<?
$arModuleVersion = array(
    "VERSION" => "1.1.5",
    "VERSION_DATE" => "2024-08-13 06:54:00"
);