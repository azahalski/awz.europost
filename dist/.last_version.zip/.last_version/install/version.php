<?
$arModuleVersion = array(
    "VERSION" => "1.0.4",
    "VERSION_DATE" => "2022-07-07 21:02:00"
);